# FeatherFPS by Meadow

A lightweight Android screen recorder with a neon-lime gaming UI, built on native Android Views. The existing `MediaProjection` + `MediaRecorder` capture path is retained so the dashboard and clip editor do not add work while recording.

## Current features

- White `FeatherFPS by Meadow` splash screen for five seconds.
- Native, dark gaming dashboard with neon yellow accents.
- 60 / 90 / 120 / 144 FPS targets; 720p / 1080p / native sizing; four bitrate presets.
- Optional microphone capture, keep-screen-awake setting, recording status, and notification STOP action.
- Saved clip library for `Movies/FeatherFPS` with play and edit actions.
- On-demand editor for start/end trimming plus source / 16:9 / 9:16 output framing using FIT, CROP, or STRETCH.
- Exports edited MP4 files as new items in `Movies/FeatherFPS`; originals are left untouched.
- GitHub Actions workflow to build and upload a debug APK artifact.

## Audio limitation

The current recording engine records microphone audio when enabled. Internal/device playback audio capture is **not implemented yet** in this build; Android playback capture requires a separate audio-recording/muxing path and app/source audio-capture policies can block it. This is intentionally not shown as a working toggle.

## Build an APK with GitHub Actions

1. Create a new GitHub repository and upload the contents of this folder (the files inside `FeatherRec/`, not an extra nested ZIP folder).
2. Push to `main` or `master`, or open **Actions → Build FeatherFPS APK → Run workflow**.
3. Open the completed run and download the `FeatherFPS-by-Meadow-APK` artifact. The debug APK is inside that artifact ZIP.

The Android SDK is installed on the GitHub runner by the workflow. This source bundle contains a lightweight `gradlew` launcher for Gradle 8.9 rather than the binary wrapper JAR.

## Important notes

- The FPS setting is a target, not a promise that every device can encode at that rate.
- Video trimming/crop/stretch re-encodes the file on demand and may use substantial CPU, battery, and storage on older phones. It does not run during screen recording.
- Android screen-capture consent remains required every time recording starts.
