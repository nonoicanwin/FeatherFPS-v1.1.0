package com.meadow.featherfps

import android.Manifest
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    // FeatherFPS by Meadow — native Views only to keep the recording UI lightweight.
    private val bg = Color.rgb(8, 9, 8)
    private val panel = Color.rgb(17, 19, 17)
    private val panelHi = Color.rgb(26, 30, 24)
    private val neon = Color.rgb(217, 255, 0)
    private val white = Color.rgb(247, 248, 244)
    private val muted = Color.rgb(151, 155, 143)
    private val edge = Color.rgb(54, 61, 39)
    private val danger = Color.rgb(255, 76, 94)
    private val splashHandler = Handler(Looper.getMainLooper())
    private var splashPending: Runnable? = null
    private val prefs by lazy { getSharedPreferences("featherfps_prefs", MODE_PRIVATE) }

    private var selectedFps = 60
    private var selectedResolution = 720 // 720, 1080, or 0 = native
    private var selectedBitrate = 8_000_000
    private var useMic = false
    private var keepAwake = true
    private var receiverRegistered = false

    private lateinit var statusText: TextView
    private lateinit var statusDot: TextView
    private lateinit var fpsButtons: Map<Int, Button>
    private lateinit var resolutionButtons: Map<Int, Button>
    private lateinit var bitrateButtons: Map<Int, Button>
    private lateinit var micCheck: CheckBox
    private lateinit var awakeCheck: CheckBox
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var presetHint: TextView

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val running = intent?.getBooleanExtra(RecorderService.EXTRA_RUNNING, false) == true
            renderRecordState(running)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The requested splash is plain white for five seconds, then the dark dashboard opens.
        window.statusBarColor = Color.WHITE
        window.navigationBarColor = Color.WHITE
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        selectedFps = prefs.getInt("fps", 60).coerceIn(60, 144).let { if (it in listOf(60, 90, 120, 144)) it else 60 }
        selectedResolution = prefs.getInt("resolution", 720).let { if (it in listOf(720, 1080, 0)) it else 720 }
        selectedBitrate = prefs.getInt("bitrate", 8_000_000).let { if (it in listOf(4_000_000, 8_000_000, 12_000_000, 20_000_000)) it else 8_000_000 }
        useMic = prefs.getBoolean("mic", false)
        keepAwake = prefs.getBoolean("awake", true)
        showSplash()
        val openDashboard = Runnable {
            splashPending = null
            window.statusBarColor = bg
            window.navigationBarColor = bg
            window.decorView.systemUiVisibility = 0
            buildUi()
            applyAwakeFlag()
            renderRecordState(getSharedPreferences(RecorderService.PREFS, MODE_PRIVATE).getBoolean(RecorderService.PREF_RECORDING, false))
            requestNotificationPermissionIfNeeded()
        }
        splashPending = openDashboard
        splashHandler.postDelayed(openDashboard, 5_000L)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED &&
            !prefs.getBoolean("asked_notification_permission", false)
        ) {
            prefs.edit().putBoolean("asked_notification_permission", true).apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQUEST_NOTIFICATIONS)
        }
    }

    private fun showSplash() {
        val splash = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.WHITE)
            setPadding(dp(28), dp(28), dp(28), dp(28))
        }
        val logo = TextView(this).apply {
            text = "F"
            textSize = 38f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(8, 9, 8))
            background = rounded(neon, 22)
        }
        splash.addView(logo, LinearLayout.LayoutParams(dp(76), dp(76)))
        splash.addView(space(19))
        splash.addView(text("FeatherFPS by Meadow", 23, Color.rgb(17, 19, 17), true).apply {
            gravity = Gravity.CENTER
            letterSpacing = -0.02f
        })
        splash.addView(space(8))
        splash.addView(text("LIGHTWEIGHT GAME CAPTURE", 10, Color.rgb(92, 94, 86), true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.18f
        })
        setContentView(splash)
    }

    override fun onDestroy() {
        splashPending?.let { splashHandler.removeCallbacks(it) }
        splashPending = null
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setFillViewport(true)
            setBackgroundColor(bg)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(19), dp(20), dp(25))
        }
        scroll.addView(root, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)

        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logo = TextView(this).apply {
            text = "F"
            textSize = 26f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            setTextColor(bg)
            background = rounded(neon, 15)
        }
        brandRow.addView(logo, LinearLayout.LayoutParams(dp(48), dp(48)))
        val brandCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, 0, 0)
        }
        brandCol.addView(text("BY MEADOW", 10, neon, true).apply { letterSpacing = 0.20f })
        brandCol.addView(text("FeatherFPS", 24, white, true))
        brandRow.addView(brandCol, LinearLayout.LayoutParams(0, -2, 1f))
        val version = text("BETA 01", 10, neon, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = rounded(Color.rgb(10, 48, 59), 50)
        }
        brandRow.addView(version)
        root.addView(brandRow, fullWidth())
        root.addView(space(10))
        root.addView(text("Capture clean. Play smooth.", 14, muted, false))
        root.addView(space(16))
        val shortcutRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        shortcutRow.addView(shortcutButton("▤  MY CLIPS") {
            startActivity(Intent(this@MainActivity, LibraryActivity::class.java))
        }, LinearLayout.LayoutParams(0, dp(45), 1f).apply { marginEnd = dp(8) })
        shortcutRow.addView(shortcutButton("✂  EDIT VIDEO") {
            startActivity(Intent(this@MainActivity, EditorActivity::class.java))
        }, LinearLayout.LayoutParams(0, dp(45), 1f))
        root.addView(shortcutRow, fullWidth())
        root.addView(space(18))

        val statusCard = panelCard(18)
        statusCard.orientation = LinearLayout.HORIZONTAL
        statusCard.gravity = Gravity.CENTER_VERTICAL
        statusCard.addView(View(this).apply {
            background = rounded(neon, 20)
        }, LinearLayout.LayoutParams(dp(4), dp(43)))
        statusCard.addView(spaceWidth(13))
        val statusColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        statusColumn.addView(text("CAPTURE ENGINE", 10, muted, true).apply { letterSpacing = 0.12f })
        statusText = text("Ready for your next clip", 15, white, true)
        statusColumn.addView(statusText)
        statusCard.addView(statusColumn, LinearLayout.LayoutParams(0, -2, 1f))
        statusDot = text("●", 16, neon, true)
        statusCard.addView(statusDot)
        root.addView(statusCard, fullWidth())
        root.addView(space(17))

        // FPS selection panel
        val fpsPanel = panelCard(20)
        addSectionTitle(fpsPanel, "01 / FRAME RATE", "Choose your capture target")
        fpsPanel.addView(space(13))
        val fpsRowA = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val fpsRowB = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val fpsEntries = linkedMapOf<Int, Button>()
        val fpsMeta = mapOf(60 to "BALANCED", 90 to "FAST", 120 to "ULTRA", 144 to "MAX")
        listOf(60, 90, 120, 144).forEachIndexed { i, fps ->
            val b = Button(this).apply {
                text = "$fps FPS\n${fpsMeta[fps]}"
                isAllCaps = false
                textSize = 13f
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                setLineSpacing(dp(2).toFloat(), 1f)
                setPadding(dp(3), dp(5), dp(3), dp(5))
                minHeight = dp(64)
                setOnClickListener { selectedFps = fps; persistSettings(); updateChoiceStyles(); updateHint() }
            }
            (if (i < 2) fpsRowA else fpsRowB).addView(b, LinearLayout.LayoutParams(0, dp(66), 1f).apply {
                if (i % 2 == 0) marginEnd = dp(8)
                else marginStart = dp(0)
            })
            fpsEntries[fps] = b
        }
        fpsPanel.addView(fpsRowA, fullWidth())
        fpsPanel.addView(space(8))
        fpsPanel.addView(fpsRowB, fullWidth())
        fpsPanel.addView(space(10))
        fpsPanel.addView(text("Higher targets can use more heat, battery and storage.", 11, muted, false))
        fpsButtons = fpsEntries
        root.addView(fpsPanel, fullWidth())
        root.addView(space(14))

        // Resolution panel
        val resPanel = panelCard(20)
        addSectionTitle(resPanel, "02 / RESOLUTION", "Match detail to your device")
        resPanel.addView(space(13))
        val resRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val resEntries = linkedMapOf<Int, Button>()
        val resLabels = linkedMapOf(720 to "720p", 1080 to "1080p", 0 to "NATIVE")
        resLabels.forEach { (value, label) ->
            val b = Button(this).apply {
                text = label
                isAllCaps = false
                textSize = 13f
                setPadding(dp(2), dp(5), dp(2), dp(5))
                setOnClickListener { selectedResolution = value; persistSettings(); updateChoiceStyles(); updateHint() }
            }
            resRow.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { if (value != 0) marginEnd = dp(7) })
            resEntries[value] = b
        }
        resPanel.addView(resRow, fullWidth())
        resPanel.addView(space(8))
        resPanel.addView(text("720p is the lightweight pick. Native keeps your screen's captured dimensions.", 11, muted, false))
        resolutionButtons = resEntries
        root.addView(resPanel, fullWidth())
        root.addView(space(14))

        // Bitrate panel
        val ratePanel = panelCard(20)
        addSectionTitle(ratePanel, "03 / VIDEO BITRATE", "More bitrate = more detail + larger files")
        ratePanel.addView(space(13))
        val rateRowA = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rateRowB = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val rateEntries = linkedMapOf<Int, Button>()
        val rates = listOf(4_000_000 to "4 Mbps", 8_000_000 to "8 Mbps", 12_000_000 to "12 Mbps", 20_000_000 to "20 Mbps")
        rates.forEachIndexed { i, pair ->
            val b = Button(this).apply {
                text = pair.second
                isAllCaps = false
                textSize = 12f
                setPadding(dp(2), dp(4), dp(2), dp(4))
                setOnClickListener { selectedBitrate = pair.first; persistSettings(); updateChoiceStyles(); updateHint() }
            }
            (if (i < 2) rateRowA else rateRowB).addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                if (i % 2 == 0) marginEnd = dp(8)
            })
            rateEntries[pair.first] = b
        }
        ratePanel.addView(rateRowA, fullWidth())
        ratePanel.addView(space(8))
        ratePanel.addView(rateRowB, fullWidth())
        bitrateButtons = rateEntries
        ratePanel.addView(space(9))
        presetHint = text("", 11, neon, false)
        ratePanel.addView(presetHint)
        root.addView(ratePanel, fullWidth())
        root.addView(space(14))

        val audioPanel = panelCard(18)
        addSectionTitle(audioPanel, "04 / EXTRAS", "Keep the setup how you like it")
        audioPanel.addView(space(6))
        micCheck = CheckBox(this).apply {
            text = "Record microphone audio"
            textSize = 13f
            setTextColor(white)
            buttonTintList = ColorStateList.valueOf(neon)
            isChecked = useMic
            setOnCheckedChangeListener { _, checked -> useMic = checked; persistSettings() }
        }
        audioPanel.addView(micCheck)
        awakeCheck = CheckBox(this).apply {
            text = "Keep display awake while FeatherFPS is open"
            textSize = 13f
            setTextColor(white)
            buttonTintList = ColorStateList.valueOf(neon)
            isChecked = keepAwake
            setOnCheckedChangeListener { _, checked -> keepAwake = checked; persistSettings(); applyAwakeFlag() }
        }
        audioPanel.addView(awakeCheck)
        audioPanel.addView(space(5))
        audioPanel.addView(text("Mic is optional. This build records microphone audio; internal device-audio capture is not yet wired into the capture engine.", 11, muted, false))
        root.addView(audioPanel, fullWidth())
        root.addView(space(18))

        startButton = Button(this).apply {
            text = "◉   START RECORDING"
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(bg)
            background = rounded(neon, 17)
            elevation = dp(5).toFloat()
            setOnClickListener { onStartPressed() }
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, dp(58)))
        stopButton = Button(this).apply {
            text = "■   STOP & SAVE CLIP"
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            setTextColor(white)
            background = rounded(Color.rgb(83, 23, 42), 17)
            visibility = View.GONE
            setOnClickListener { stopRecording() }
        }
        root.addView(stopButton, LinearLayout.LayoutParams(-1, dp(58)))
        root.addView(space(13))
        val output = text("SAVES TO  Movies/FeatherFPS  ·  MP4 / H.264", 11, neon, true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.04f
        }
        root.addView(output, fullWidth())
        root.addView(space(7))
        root.addView(text("FPS is a target, not a guarantee. The phone's display refresh, Android capture path and video encoder decide the real recorded frame rate.", 11, muted, false).apply {
            gravity = Gravity.CENTER
        }, fullWidth())
        root.addView(space(12))
        root.addView(text("FEATHERFPS BY MEADOW  •  LIGHTWEIGHT CAPTURE", 9, Color.rgb(96, 104, 75), true).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }, fullWidth())

        updateChoiceStyles()
        updateHint()
    }

    private fun shortcutButton(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 11f
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        setTextColor(neon)
        background = rounded(panelHi, 12).also { it.setStroke(dp(1), edge) }
        setOnClickListener { action() }
    }

    private fun addSectionTitle(parent: LinearLayout, kicker: String, subtitle: String) {
        parent.addView(text(kicker, 10, neon, true).apply { letterSpacing = 0.15f })
        parent.addView(space(4))
        parent.addView(text(subtitle, 13, white, true))
    }

    private fun onStartPressed() {
        if (useMic && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Uses the activity result API supported by the minimum Android version.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                persistSettings()
                val service = Intent(this, RecorderService::class.java).apply {
                    putExtra(RecorderService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(RecorderService.EXTRA_RESULT_DATA, data)
                    putExtra(RecorderService.EXTRA_FPS, selectedFps)
                    putExtra(RecorderService.EXTRA_RESOLUTION, selectedResolution)
                    putExtra(RecorderService.EXTRA_BITRATE, selectedBitrate)
                    putExtra(RecorderService.EXTRA_MIC, useMic)
                }
                try {
                    startForegroundService(service)
                    statusText.text = "Starting ${selectedFps} FPS capture…"
                } catch (failure: Exception) {
                    Toast.makeText(this, "Couldn't start the recorder: ${failure.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this, "Screen capture cancelled", Toast.LENGTH_SHORT).show()
            }
        }
    }

    @Deprecated("Permission callback for the minimum Android version.")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_MIC) {
            if (grantResults.firstOrNull() != PackageManager.PERMISSION_GRANTED) {
                useMic = false
                micCheck.isChecked = false
                persistSettings()
                Toast.makeText(this, "Microphone permission not granted; continuing without audio", Toast.LENGTH_LONG).show()
            }
            requestScreenCapture()
        }
    }

    private fun stopRecording() {
        startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
    }

    override fun onResume() {
        super.onResume()
        if (!receiverRegistered) {
            val filter = IntentFilter(RecorderService.ACTION_STATE)
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
            else {
                @Suppress("DEPRECATION")
                registerReceiver(stateReceiver, filter)
            }
            receiverRegistered = true
        }
        renderRecordState(getSharedPreferences(RecorderService.PREFS, MODE_PRIVATE).getBoolean(RecorderService.PREF_RECORDING, false))
    }

    override fun onPause() {
        if (receiverRegistered) {
            unregisterReceiver(stateReceiver)
            receiverRegistered = false
        }
        super.onPause()
    }

    private fun renderRecordState(active: Boolean) {
        if (!::statusText.isInitialized || !::startButton.isInitialized || !::stopButton.isInitialized) return
        val displayedFps = getSharedPreferences(RecorderService.PREFS, MODE_PRIVATE).getInt(RecorderService.PREF_ACTIVE_FPS, selectedFps)
        statusText.text = if (active) "Recording · $displayedFps FPS target" else "Ready for your next clip"
        statusDot.setTextColor(if (active) danger else neon)
        startButton.visibility = if (active) View.GONE else View.VISIBLE
        stopButton.visibility = if (active) View.VISIBLE else View.GONE
        if (active) startButton.isEnabled = false else startButton.isEnabled = true
    }

    private fun updateChoiceStyles() {
        if (!::fpsButtons.isInitialized) return
        fpsButtons.forEach { (value, button) -> styleChoice(button, value == selectedFps, true) }
        resolutionButtons.forEach { (value, button) -> styleChoice(button, value == selectedResolution, false) }
        bitrateButtons.forEach { (value, button) -> styleChoice(button, value == selectedBitrate, false) }
    }

    private fun styleChoice(button: Button, selected: Boolean, large: Boolean) {
        button.background = rounded(if (selected) Color.rgb(44, 54, 8) else panelHi, if (large) 15 else 12).also {
            it.setStroke(dp(if (selected) 1.5f.toInt() else 1), if (selected) neon else edge)
        }
        button.setTextColor(if (selected) neon else white)
    }

    private fun updateHint() {
        if (!::presetHint.isInitialized) return
        val sizeName = when (selectedResolution) { 720 -> "720p"; 1080 -> "1080p"; else -> "native" }
        val rateName = when (selectedBitrate) { 4_000_000 -> "4"; 8_000_000 -> "8"; 12_000_000 -> "12"; else -> "20" }
        val hint = when {
            selectedFps >= 120 && selectedResolution == 0 -> "MAX preset: native resolution + high FPS can overload mobile encoders."
            selectedFps >= 120 -> "High-FPS preset: try 720p first for the best chance of sustained capture."
            selectedFps == 90 -> "Balanced high-refresh preset: watch for heat during long sessions."
            else -> "Balanced preset: a good starting point for longer recordings."
        }
        presetHint.text = "$hint\nSelected: $selectedFps FPS  ·  $sizeName  ·  $rateName Mbps"
    }

    private fun persistSettings() {
        prefs.edit()
            .putInt("fps", selectedFps)
            .putInt("resolution", selectedResolution)
            .putInt("bitrate", selectedBitrate)
            .putBoolean("mic", useMic)
            .putBoolean("awake", keepAwake)
            .apply()
    }

    private fun applyAwakeFlag() {
        if (keepAwake) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun panelCard(radius: Int) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = rounded(panel, radius).also { it.setStroke(dp(1), edge) }
    }

    private fun text(value: String, sizeSp: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = sizeSp.toFloat()
        setTextColor(color)
        if (bold) setTypeface(Typeface.create("sans-serif", Typeface.BOLD))
        includeFontPadding = true
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun space(heightDp: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(heightDp)) }
    private fun spaceWidth(widthDp: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(widthDp), 1) }
    private fun fullWidth() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        private const val REQUEST_CAPTURE = 301
        private const val REQUEST_MIC = 302
        private const val REQUEST_NOTIFICATIONS = 303
    }
}
