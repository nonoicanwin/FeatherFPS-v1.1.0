package com.meadow.featherfps

import android.app.Activity
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Lightweight library view over FeatherFPS-owned recordings in Movies/FeatherFPS. */
class LibraryActivity : Activity() {
    private val bg = Color.rgb(8, 9, 8)
    private val panel = Color.rgb(17, 19, 17)
    private val panelHi = Color.rgb(26, 30, 24)
    private val neon = Color.rgb(217, 255, 0)
    private val white = Color.rgb(247, 248, 244)
    private val muted = Color.rgb(151, 155, 143)
    private val edge = Color.rgb(54, 61, 39)
    private lateinit var list: LinearLayout
    private lateinit var count: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildLayout()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) refreshClips()
    }

    private fun buildLayout() {
        val scroll = ScrollView(this).apply {
            setFillViewport(true)
            setBackgroundColor(bg)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        scroll.addView(root, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)

        root.addView(text("FEATHERFPS  /  LIBRARY", 10, neon, true).apply { letterSpacing = 0.15f })
        root.addView(space(6))
        root.addView(text("My clips", 29, white, true))
        root.addView(space(4))
        count = text("Scanning Movies/FeatherFPS…", 12, muted, false)
        root.addView(count)
        root.addView(space(18))
        root.addView(button("↻  REFRESH CLIPS", filled = false) { refreshClips() }, fullWidth())
        root.addView(space(14))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list, fullWidth())
        root.addView(space(12))
        root.addView(button("←  BACK TO HOME", filled = true) { finish() }, fullWidth())
    }

    private fun refreshClips() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val clips = mutableListOf<Clip>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DURATION,
            MediaStore.MediaColumns.RELATIVE_PATH
        )
        val selection = "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?"
        val args = arrayOf("Movies/FeatherFPS%")
        try {
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                args,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    clips.add(
                        Clip(
                            ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                            cursor.getString(nameCol) ?: "FeatherFPS clip.mp4",
                            cursor.getLong(sizeCol),
                            cursor.getLong(dateCol),
                            cursor.getLong(durationCol)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Could not read the recordings folder", Toast.LENGTH_LONG).show()
        }
        count.text = "${clips.size} clip${if (clips.size == 1) "" else "s"}  ·  Movies/FeatherFPS"
        if (clips.isEmpty()) {
            val empty = card().apply { gravity = Gravity.CENTER_HORIZONTAL }
            empty.addView(text("NO CLIPS YET", 12, neon, true).apply { gravity = Gravity.CENTER })
            empty.addView(space(8))
            empty.addView(text("Your recordings will appear here after you stop a capture.", 13, muted, false).apply {
                gravity = Gravity.CENTER
            })
            list.addView(empty, fullWidth())
        } else {
            clips.forEachIndexed { index, clip ->
                val item = card()
                item.addView(text(clip.name, 15, white, true))
                item.addView(space(5))
                val dateText = if (clip.dateAdded > 0L) {
                    SimpleDateFormat("dd MMM yyyy · HH:mm", Locale.getDefault()).format(Date(clip.dateAdded * 1000L))
                } else "Saved video"
                item.addView(text("${formatBytes(clip.size)}  ·  ${formatDuration(clip.duration)}  ·  $dateText", 11, muted, false))
                item.addView(space(12))
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(button("▶  PLAY", filled = false) { openClip(clip.uri) }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(8) })
                actions.addView(button("✂  EDIT", filled = true) { editClip(clip.uri) }, LinearLayout.LayoutParams(0, dp(42), 1f))
                item.addView(actions, fullWidth())
                list.addView(item, fullWidth())
                if (index != clips.lastIndex) list.addView(space(11))
            }
        }
    }

    private fun openClip(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (_: Exception) {
            Toast.makeText(this, "No video player is available", Toast.LENGTH_LONG).show()
        }
    }

    private fun editClip(uri: Uri) {
        startActivity(Intent(this, EditorActivity::class.java).putExtra(EditorActivity.EXTRA_INPUT_URI, uri.toString()))
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1_073_741_824L -> String.format(Locale.US, "%.2f GB", bytes / 1_073_741_824.0)
        bytes >= 1_048_576L -> String.format(Locale.US, "%.1f MB", bytes / 1_048_576.0)
        bytes >= 1024L -> String.format(Locale.US, "%.0f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    private fun formatDuration(ms: Long): String {
        val seconds = (ms / 1000L).coerceAtLeast(0L)
        return String.format(Locale.US, "%d:%02d", seconds / 60L, seconds % 60L)
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(panel, 15).also { it.setStroke(dp(1), edge) }
    }

    private fun button(label: String, filled: Boolean, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 11f
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        setTextColor(if (filled) bg else neon)
        background = rounded(if (filled) neon else panelHi, 11).also {
            if (!filled) it.setStroke(dp(1), edge)
        }
        setOnClickListener { action() }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun fullWidth() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()

    private data class Clip(val uri: Uri, val name: String, val size: Long, val dateAdded: Long, val duration: Long)
}
