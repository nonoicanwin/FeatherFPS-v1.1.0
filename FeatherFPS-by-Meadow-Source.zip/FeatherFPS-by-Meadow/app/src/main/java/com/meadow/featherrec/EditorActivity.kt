package com.meadow.featherfps

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.common.Effects
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ExportException
import java.io.File
import java.io.FileInputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Trim, crop, or stretch an existing video. These edits run only when the user exports. */
@OptIn(UnstableApi::class)
class EditorActivity : Activity() {
    private val bg = Color.rgb(8, 9, 8)
    private val panel = Color.rgb(17, 19, 17)
    private val panelHi = Color.rgb(26, 30, 24)
    private val neon = Color.rgb(217, 255, 0)
    private val white = Color.rgb(247, 248, 244)
    private val muted = Color.rgb(151, 155, 143)
    private val edge = Color.rgb(54, 61, 39)

    private var selectedUri: Uri? = null
    private var selectedAspect = Aspect.SOURCE
    private var selectedLayout = Presentation.LAYOUT_SCALE_TO_FIT
    private var isExporting = false

    private lateinit var selectedName: TextView
    private lateinit var startSeconds: EditText
    private lateinit var endSeconds: EditText
    private lateinit var status: TextView
    private lateinit var exportButton: Button
    private lateinit var aspectButtons: Map<Aspect, Button>
    private lateinit var layoutButtons: Map<Int, Button>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        intent.getStringExtra(EXTRA_INPUT_URI)?.let { setSelectedUri(Uri.parse(it)) }
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setFillViewport(true)
            setBackgroundColor(bg)
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        scroll.addView(root, ViewGroup.LayoutParams(-1, -2))
        setContentView(scroll)

        root.addView(text("FEATHERFPS  /  STUDIO", 10, neon, true).apply { letterSpacing = 0.15f })
        root.addView(space(6))
        root.addView(text("Clip editor", 29, white, true))
        root.addView(space(5))
        root.addView(text("Trim a recording, then crop or stretch it for your preferred aspect ratio.", 13, muted, false))
        root.addView(space(18))

        val sourceCard = card()
        addSectionTitle(sourceCard, "01 / SOURCE VIDEO", "Choose any video file")
        sourceCard.addView(space(10))
        sourceCard.addView(button("SELECT VIDEO", filled = false) { chooseVideo() }, fullWidth())
        sourceCard.addView(space(10))
        selectedName = text("No video selected", 12, muted, false)
        sourceCard.addView(selectedName)
        root.addView(sourceCard, fullWidth())
        root.addView(space(12))

        val trimCard = card()
        addSectionTitle(trimCard, "02 / TRIM RANGE", "Times are in seconds")
        trimCard.addView(space(11))
        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val startCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        startCol.addView(text("START", 10, neon, true))
        startSeconds = timeInput("0")
        startCol.addView(startSeconds, fullWidth())
        val endCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        endCol.addView(text("END (0 = FULL CLIP)", 10, neon, true))
        endSeconds = timeInput("0")
        endCol.addView(endSeconds, fullWidth())
        timeRow.addView(startCol, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(8) })
        timeRow.addView(endCol, LinearLayout.LayoutParams(0, -2, 1f))
        trimCard.addView(timeRow, fullWidth())
        trimCard.addView(space(8))
        trimCard.addView(text("If you trim from the middle, the app re-encodes the result so the selected start can be respected.", 11, muted, false))
        root.addView(trimCard, fullWidth())
        root.addView(space(12))

        val aspectCard = card()
        addSectionTitle(aspectCard, "03 / ASPECT RATIO", "Choose output framing")
        aspectCard.addView(space(11))
        val aspectRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val aspects = linkedMapOf<Aspect, Button>()
        listOf(Aspect.SOURCE, Aspect.LANDSCAPE, Aspect.PORTRAIT).forEach { aspect ->
            val label = when (aspect) { Aspect.SOURCE -> "SOURCE"; Aspect.LANDSCAPE -> "16:9"; Aspect.PORTRAIT -> "9:16" }
            val b = button(label, filled = false) {
                selectedAspect = aspect
                updateSelections()
            }
            aspectRow.addView(b, LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                if (aspect != Aspect.PORTRAIT) marginEnd = dp(7)
            })
            aspects[aspect] = b
        }
        aspectCard.addView(aspectRow, fullWidth())
        aspectCard.addView(space(13))
        aspectCard.addView(text("LAYOUT MODE", 10, neon, true))
        aspectCard.addView(space(7))
        val modeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val modes = linkedMapOf<Int, Button>()
        val modeOptions = listOf(
            Presentation.LAYOUT_SCALE_TO_FIT to "FIT",
            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP to "CROP",
            Presentation.LAYOUT_STRETCH_TO_FIT to "STRETCH"
        )
        modeOptions.forEachIndexed { index, pair ->
            val b = button(pair.second, filled = false) {
                selectedLayout = pair.first
                updateSelections()
            }
            modeRow.addView(b, LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                if (index != modeOptions.lastIndex) marginEnd = dp(7)
            })
            modes[pair.first] = b
        }
        aspectCard.addView(modeRow, fullWidth())
        aspectCard.addView(space(8))
        aspectCard.addView(text("FIT adds padding to preserve the whole picture. CROP fills the frame by cutting off edges. STRETCH fills the frame and may distort shapes.", 11, muted, false))
        root.addView(aspectCard, fullWidth())
        aspectButtons = aspects
        layoutButtons = modes
        root.addView(space(14))

        status = text("Edits are exported to Movies/FeatherFPS as a new MP4. Your original clip stays untouched.", 12, muted, false)
        root.addView(status, fullWidth())
        root.addView(space(13))
        exportButton = button("EXPORT EDITED CLIP", filled = true) { exportEditedVideo() }
        root.addView(exportButton, LinearLayout.LayoutParams(-1, dp(55)))
        root.addView(space(10))
        root.addView(button("←  BACK", filled = false) { finish() }, fullWidth())
        updateSelections()
    }

    private fun chooseVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        try {
            startActivityForResult(intent, REQUEST_VIDEO)
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't open the video picker", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Uses activity result API compatible with the current minimum Android version.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VIDEO && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                if ((data.flags and Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION) != 0) {
                    contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } catch (_: Exception) { }
            setSelectedUri(uri)
        }
    }

    private fun setSelectedUri(uri: Uri) {
        selectedUri = uri
        var name = "Selected video"
        try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
            }
        } catch (_: Exception) { }
        selectedName.text = name
        selectedName.setTextColor(white)
        status.text = "Ready to edit: $name"
    }

    private fun exportEditedVideo() {
        if (isExporting) return
        val inputUri = selectedUri
        if (inputUri == null) {
            Toast.makeText(this, "Select a video first", Toast.LENGTH_SHORT).show()
            return
        }
        val start = startSeconds.text.toString().toDoubleOrNull() ?: 0.0
        val end = endSeconds.text.toString().toDoubleOrNull() ?: 0.0
        if (start < 0 || end < 0 || (end > 0 && end <= start)) {
            Toast.makeText(this, "End time must be greater than start time", Toast.LENGTH_LONG).show()
            return
        }

        val startMs = (start * 1000.0).toLong()
        val endMs = if (end > 0) (end * 1000.0).toLong() else 0L
        val mediaBuilder = MediaItem.Builder().setUri(inputUri)
        if (startMs > 0 || endMs > 0) {
            val clipBuilder = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs)
            if (endMs > 0) clipBuilder.setEndPositionMs(endMs)
            mediaBuilder.setClippingConfiguration(clipBuilder.build())
        }

        val videoEffects = if (selectedAspect == Aspect.SOURCE) {
            emptyList()
        } else {
            val ratio = if (selectedAspect == Aspect.LANDSCAPE) 16f / 9f else 9f / 16f
            listOf(Presentation.createForAspectRatio(ratio, selectedLayout))
        }
        val editedItem = EditedMediaItem.Builder(mediaBuilder.build())
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val tempFile = File(cacheDir, "featherfps_edit_$timestamp.mp4")
        isExporting = true
        exportButton.isEnabled = false
        exportButton.text = "EXPORTING…"
        status.text = "Exporting on this device. Keep FeatherFPS open until it finishes."
        status.setTextColor(neon)

        val listener = object : Transformer.Listener {
            override fun onCompleted(composition: Composition, result: ExportResult) {
                publishEditedFile(tempFile)
            }

            override fun onError(composition: Composition, result: ExportResult, exception: ExportException) {
                tempFile.delete()
                finishExport("Export failed: ${exception.message ?: "the video couldn't be processed"}", success = false)
            }
        }
        try {
            Transformer.Builder(this)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(listener)
                .build()
                .start(editedItem, tempFile.absolutePath)
        } catch (e: Exception) {
            tempFile.delete()
            finishExport("Export couldn't start: ${e.message ?: "unsupported video"}", success = false)
        }
    }

    private fun publishEditedFile(tempFile: File) {
        Thread {
            var outputUri: Uri? = null
            try {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, "FeatherFPS_Edit_$timestamp.mp4")
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/FeatherFPS")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                outputUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Could not create the output video")
                val outputStream = contentResolver.openOutputStream(outputUri, "w")
                    ?: throw IllegalStateException("Could not open the output video")
                FileInputStream(tempFile).use { input -> outputStream.use { output -> input.copyTo(output) } }
                contentResolver.update(outputUri, ContentValues().apply {
                    put(MediaStore.MediaColumns.IS_PENDING, 0)
                }, null, null)
                tempFile.delete()
                runOnUiThread { finishExport("Saved edited video to Movies/FeatherFPS.", success = true) }
            } catch (e: Exception) {
                outputUri?.let { try { contentResolver.delete(it, null, null) } catch (_: Exception) { } }
                tempFile.delete()
                runOnUiThread { finishExport("Couldn't save export: ${e.message ?: "storage error"}", success = false) }
            }
        }.start()
    }

    private fun finishExport(message: String, success: Boolean) {
        isExporting = false
        exportButton.isEnabled = true
        exportButton.text = "EXPORT EDITED CLIP"
        status.text = message
        status.setTextColor(if (success) neon else Color.rgb(255, 114, 122))
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun updateSelections() {
        if (!::aspectButtons.isInitialized || !::layoutButtons.isInitialized) return
        aspectButtons.forEach { (value, button) -> style(button, value == selectedAspect) }
        layoutButtons.forEach { (value, button) -> style(button, value == selectedLayout) }
        layoutButtons.values.forEach { it.isEnabled = selectedAspect != Aspect.SOURCE }
        if (selectedAspect == Aspect.SOURCE) {
            layoutButtons.values.forEach { it.alpha = 0.45f }
        } else {
            layoutButtons.values.forEach { it.alpha = 1f }
        }
    }

    private fun addSectionTitle(parent: LinearLayout, title: String, subtitle: String) {
        parent.addView(text(title, 10, neon, true).apply { letterSpacing = 0.13f })
        parent.addView(space(4))
        parent.addView(text(subtitle, 13, white, true))
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        background = rounded(panel, 15).also { it.setStroke(dp(1), edge) }
    }

    private fun button(label: String, filled: Boolean, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 11f
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        setTextColor(if (filled) bg else neon)
        background = rounded(if (filled) neon else panelHi, 11).also {
            if (!filled) it.setStroke(dp(1), edge)
        }
        setOnClickListener { action() }
    }

    private fun timeInput(defaultValue: String) = EditText(this).apply {
        setText(defaultValue)
        textSize = 14f
        setTextColor(white)
        setHintTextColor(muted)
        hint = "seconds"
        inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        setSingleLine(true)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = rounded(panelHi, 10).also { it.setStroke(dp(1), edge) }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun style(button: Button, selected: Boolean) {
        button.background = rounded(if (selected) Color.rgb(44, 54, 8) else panelHi, 11).also {
            it.setStroke(dp(if (selected) 2 else 1), if (selected) neon else edge)
        }
        button.setTextColor(if (selected) neon else white)
    }

    private fun space(height: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(height)) }
    private fun fullWidth() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()

    private enum class Aspect { SOURCE, LANDSCAPE, PORTRAIT }

    companion object {
        const val EXTRA_INPUT_URI = "input_uri"
        private const val REQUEST_VIDEO = 410
    }
}
